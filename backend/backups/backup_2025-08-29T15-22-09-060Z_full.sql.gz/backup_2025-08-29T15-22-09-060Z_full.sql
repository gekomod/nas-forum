PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      permissions TEXT
    );
INSERT INTO roles VALUES(1,'Administrator','{"manage_users": true, "manage_categories": true, "manage_threads": true, "manage_posts": true, "delete_any_content": true, "assign_roles": true, "manage_backups": true}');
INSERT INTO roles VALUES(2,'Moderator','{"manage_threads": true, "manage_posts": true, "delete_any_content": true}');
INSERT INTO roles VALUES(3,'Użytkownik','{"create_threads": true, "create_posts": true, "edit_own_content": true, "delete_own_content": true}');
INSERT INTO roles VALUES(4,'Zbanowany','{}');
INSERT INTO roles VALUES(5,'VIP','{"create_threads": true, "create_posts": true, "edit_own_content": true, "delete_own_content": true, "extended_signature": true, "custom_avatar": true}');
INSERT INTO roles VALUES(6,'Redaktor','{"create_threads": true, "create_posts": true, "edit_own_content": true, "delete_own_content": true, "create_announcements": true}');
CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role_id INTEGER DEFAULT 3,
      avatar TEXT,
      signature TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME, notification_settings TEXT DEFAULT '{"email_notifications": true, "push_notifications": true}', location TEXT DEFAULT NULL, website TEXT DEFAULT NULL, bio TEXT DEFAULT NULL, reputation INTEGER DEFAULT 0,
      FOREIGN KEY (role_id) REFERENCES roles (id)
    );
INSERT INTO users VALUES(1,'admin','zaba141@o2.pl','$2b$10$Ay9I9TJBzo/8FvVtfNUTS.VWV/bD0LEH4r4m1SRvLjjOADE1gMdw6',1,'/uploads/avatars/avatar-undefined-1756143268044-292057551.jpeg',NULL,'2025-08-22 20:49:46','2025-08-29 17:21:51','{"email_notifications": true, "push_notifications": true}',NULL,NULL,NULL,40);
INSERT INTO users VALUES(2,'test','jnowakk11@gmail.com','$2b$10$o7DpYRQ59yj6ZQzfoTFB5up.L2cuG8RuDg/rv/UzqlgeNpagBDuru',3,NULL,NULL,'2025-08-25 20:29:05','2025-08-27 20:26:05','{"email_notifications": true, "push_notifications": true}',NULL,NULL,NULL,1);
CREATE TABLE categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      icon TEXT,
      description TEXT,
      threads INTEGER DEFAULT 0,
      posts INTEGER DEFAULT 0,
      last_post_author TEXT,
      last_post_time TEXT,
      is_locked BOOLEAN DEFAULT 0,
      required_role INTEGER DEFAULT NULL
    , position INTEGER DEFAULT 0);
INSERT INTO categories VALUES(1,'Ogłoszenia','mdi:bullhorn','Ogłoszenia administracji i ważne informacje',50,209,'admin','2025-08-29T00:06:16.009Z',0,NULL,1);
INSERT INTO categories VALUES(2,'Problemy techniczne','mdi:tools','Problemy z konfiguracją, instalacją i działaniem NAS',328,1545,'admin','2025-08-22T22:55:00.689Z',0,NULL,3);
INSERT INTO categories VALUES(3,'Dyskusje ogólne','mdi:forum','Ogólne dyskusje dotyczące NAS i nie tylko',572,2889,'admin','2025-08-29T00:07:59.572Z',0,NULL,2);
INSERT INTO categories VALUES(4,'Propozycje','mdi:lightbulb','Propozycje nowych funkcji i usprawnień',192,874,'Tomasz Wiśniewski','1 godzinę temu',0,NULL,4);
INSERT INTO categories VALUES(5,'Off-top','mdi:chat','Dyskusje na dowolne tematy niezwiązane z NAS',111,376,'KinoMan','28 minut temu',0,NULL,6);
INSERT INTO categories VALUES(6,'Pobieralnia','mdi:folder','Pliki do pobrania, Aktualne wersje, Dodatki, Pluginy.',0,0,NULL,NULL,1,NULL,5);
CREATE TABLE threads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category_id INTEGER,
      user_id INTEGER,
      title TEXT NOT NULL,
      tag TEXT,
      author TEXT NOT NULL,
      date TEXT,
      replies INTEGER DEFAULT 0,
      views INTEGER DEFAULT 0,
      last_post_author TEXT,
      last_post_time TEXT, is_closed INTEGER DEFAULT 0, is_sticky INTEGER DEFAULT 0,
      FOREIGN KEY (category_id) REFERENCES categories (id),
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO threads VALUES(8,1,1,'Repozytorium Debian','tutorial','admin','2025-08-24T11:45:08.211Z',1,97,'admin','2025-08-25T16:52:22.295Z',0,1);
INSERT INTO threads VALUES(12,1,1,'dsf546','','admin','2025-08-28T23:51:35.877Z',0,4,NULL,NULL,0,0);
INSERT INTO threads VALUES(13,1,1,'jebac to','','admin','2025-08-28T23:58:42.094Z',0,2,NULL,NULL,0,0);
INSERT INTO threads VALUES(14,1,1,'sthsrth','','admin','2025-08-29T00:02:08.040Z',0,2,NULL,NULL,0,0);
INSERT INTO threads VALUES(15,1,1,'dupa55','','admin','2025-08-29T00:06:16.009Z',0,3,NULL,NULL,0,0);
CREATE TABLE posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id INTEGER,
      user_id INTEGER,
      author TEXT NOT NULL,
      content TEXT,
      date TEXT, edited_at DATETIME,
      FOREIGN KEY (thread_id) REFERENCES threads (id),
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO posts VALUES(13,6,1,'admin',replace('Testuje tworzenie tematóœ\n\nPodpowiedzi formatowania:\n**pogrubienie** - tekst pogrubiony\n*kursywa* - tekst kursywą\n`kod` - fragment kodu\n> cytat - blok cytatu\n[link](https://...) - hiperłącze\n![obraz](https://www.shutterstock.com/image-vector/admin-icon-symbol-flat-design-260nw-1075685549.jpg) - obrazek','\n',char(10)),'2025-08-23T06:31:43.091Z',NULL);
INSERT INTO posts VALUES(15,8,1,'admin',replace('# 🏗️ NAS Debian Repository\n\nRepozytorium Debian dla pakietów NAS: `nas-panel`, `nas-web`, i innych.\n\n## 📦 Dostępne pakiety\n\n- `nas-panel` - Panel zarządzania NAS\n- `nas-web` - Serwer WWW dla NAS\n\n## 🚀 Szybka instalacja\n\n```bash\n# Dodaj repozytorium\ncurl -sSL https://repo.naspanel.site/install-repo.sh | sudo bash\n\n# Zainstaluj pakiety\nsudo apt-get update\nsudo apt-get install nas-panel nas-web\n```\n\n## 🔧 Ręczna instalacja repozytorium\n\n```bash\n# Dodaj klucz GPG\nsudo wget -qO - https://repo.naspanel.site/KEY.gpg | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/nas-repo.gpg\n\n# Dodaj źródło\necho "deb [arch=amd64 signed-by=/etc/apt/trusted.gpg.d/nas-repo.gpg] https://repo.naspanel.site/ stable main" | sudo tee /etc/apt/sources.list.d/nas-repo.list\n\n# Aktualizuj i instaluj\nsudo apt-get update\nsudo apt-get install nas-panel\n```\n\n## 🔒 Bezpieczeństwo\n\nRepozytorium jest podpisane kluczem GPG. Klucz publiczny znajduje się w `KEY.gpg`.','\n',char(10)),'2025-08-24T11:45:08.211Z','2025-08-24 15:50:16');
INSERT INTO posts VALUES(17,8,1,'admin','testttt 1234','2025-08-25T16:52:22.295Z','2025-08-28 23:21:35');
INSERT INTO posts VALUES(18,9,2,'test','hfd dfhdfh','2025-08-25T23:53:05.899Z',NULL);
INSERT INTO posts VALUES(21,12,1,'admin','hj ghj gh','2025-08-28T23:51:35.877Z',NULL);
INSERT INTO posts VALUES(22,13,1,'admin','dsafdsfdsfsdf','2025-08-28T23:58:42.094Z',NULL);
INSERT INTO posts VALUES(23,14,1,'admin','5464 ww 7','2025-08-29T00:02:08.040Z',NULL);
INSERT INTO posts VALUES(24,15,1,'admin','12345','2025-08-29T00:06:16.009Z',NULL);
CREATE TABLE auth_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      token TEXT UNIQUE NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
CREATE TABLE thread_subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      thread_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (thread_id) REFERENCES threads (id),
      UNIQUE(user_id, thread_id)
    );
INSERT INTO thread_subscriptions VALUES(2,1,8,'2025-08-25 16:51:47');
CREATE TABLE notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL, -- 'new_reply', 'thread_update', 'mention', 'system'
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      related_thread_id INTEGER,
      related_post_id INTEGER,
      related_user_id INTEGER,
      is_read BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (related_thread_id) REFERENCES threads (id),
      FOREIGN KEY (related_post_id) REFERENCES posts (id),
      FOREIGN KEY (related_user_id) REFERENCES users (id)
    );
INSERT INTO notifications VALUES(1,2,'system','TEST','HAHAHA',NULL,NULL,1,1,'2025-08-26 21:07:27');
INSERT INTO notifications VALUES(3,1,'achievement','Nowe osiągnięcie!','Odblokowałeś osiągnięcie: <strong>Twórca wątków</strong> - Utwórz 5 wątków',NULL,NULL,NULL,1,'2025-08-29 00:06:16');
INSERT INTO notifications VALUES(4,1,'achievement','Nowe osiągnięcie!','Odblokowałeś osiągnięcie: <strong>Pierwszy post</strong> - Napisz swój pierwszy post na forum',NULL,NULL,NULL,1,'2025-08-29 00:07:59');
CREATE TABLE user_notification_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      email_notifications BOOLEAN DEFAULT 1,
      push_notifications BOOLEAN DEFAULT 1,
      notify_on_reply BOOLEAN DEFAULT 1,
      notify_on_mention BOOLEAN DEFAULT 1,
      notify_on_thread_update BOOLEAN DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users (id),
      UNIQUE(user_id)
    );
INSERT INTO user_notification_settings VALUES(5,1,1,1,1,1,1);
INSERT INTO user_notification_settings VALUES(7,2,1,1,1,1,1);
CREATE TABLE private_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id TEXT NOT NULL,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      is_read BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sender_id) REFERENCES users (id),
      FOREIGN KEY (receiver_id) REFERENCES users (id)
    );
INSERT INTO private_messages VALUES(3,'2_2',2,2,'fjfgjfgjfjfgj',1,'2025-08-25 22:03:51');
CREATE TABLE user_pm_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      allow_private_messages BOOLEAN DEFAULT 1,
      notify_on_pm BOOLEAN DEFAULT 1,
      save_sent_messages BOOLEAN DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO user_pm_settings VALUES(2,1,1,1,1);
INSERT INTO user_pm_settings VALUES(4,2,1,1,1);
CREATE TABLE user_read_threads (
      user_id INTEGER,
      thread_id INTEGER,
      read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, thread_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (thread_id) REFERENCES threads(id)
    );
INSERT INTO user_read_threads VALUES(2,8,'2025-08-25 23:52:51');
INSERT INTO user_read_threads VALUES(1,10,'2025-08-28 23:48:57');
INSERT INTO user_read_threads VALUES(1,9,'2025-08-29 00:07:59');
INSERT INTO user_read_threads VALUES(1,8,'2025-08-29 00:10:11');
INSERT INTO user_read_threads VALUES(1,14,'2025-08-29 00:10:21');
INSERT INTO user_read_threads VALUES(1,13,'2025-08-29 00:10:24');
INSERT INTO user_read_threads VALUES(1,12,'2025-08-29 00:10:26');
INSERT INTO user_read_threads VALUES(1,15,'2025-08-29 13:14:16');
CREATE TABLE user_read_posts (
      user_id INTEGER,
      post_id INTEGER,
      read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, post_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (post_id) REFERENCES posts(id)
    );
INSERT INTO user_read_posts VALUES(2,15,'2025-08-25 23:52:51');
INSERT INTO user_read_posts VALUES(2,17,'2025-08-25 23:52:51');
INSERT INTO user_read_posts VALUES(1,19,'2025-08-28 23:48:53');
INSERT INTO user_read_posts VALUES(1,18,'2025-08-29 00:07:59');
INSERT INTO user_read_posts VALUES(1,25,'2025-08-29 00:07:59');
INSERT INTO user_read_posts VALUES(1,15,'2025-08-29 00:10:11');
INSERT INTO user_read_posts VALUES(1,17,'2025-08-29 00:10:11');
INSERT INTO user_read_posts VALUES(1,23,'2025-08-29 00:10:21');
INSERT INTO user_read_posts VALUES(1,22,'2025-08-29 00:10:24');
INSERT INTO user_read_posts VALUES(1,21,'2025-08-29 00:10:26');
INSERT INTO user_read_posts VALUES(1,24,'2025-08-29 13:14:16');
CREATE TABLE user_category_visits (
      user_id INTEGER,
      category_id INTEGER,
      last_visit DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, category_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (category_id) REFERENCES categories(id)
    );
INSERT INTO user_category_visits VALUES(2,6,'2025-08-25 23:13:56');
INSERT INTO user_category_visits VALUES(2,5,'2025-08-25 23:48:30');
INSERT INTO user_category_visits VALUES(2,4,'2025-08-25 23:48:32');
INSERT INTO user_category_visits VALUES(2,2,'2025-08-25 23:48:34');
INSERT INTO user_category_visits VALUES(2,1,'2025-08-25 23:52:51');
INSERT INTO user_category_visits VALUES(2,3,'2025-08-25 23:52:59');
INSERT INTO user_category_visits VALUES(1,6,'2025-08-25 23:55:04');
INSERT INTO user_category_visits VALUES(1,5,'2025-08-28 19:18:04');
INSERT INTO user_category_visits VALUES(1,2,'2025-08-28 19:18:07');
INSERT INTO user_category_visits VALUES(1,3,'2025-08-29 00:07:59');
INSERT INTO user_category_visits VALUES(1,1,'2025-08-29 13:14:16');
CREATE TABLE reputation_votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  target_type TEXT NOT NULL CHECK (target_type IN ('post', 'thread')),
  target_id INTEGER NOT NULL,
  vote_type TEXT NOT NULL CHECK (vote_type IN ('upvote', 'downvote')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id),
  UNIQUE(user_id, target_type, target_id)
);
INSERT INTO reputation_votes VALUES(2,1,'post',18,'upvote','2025-08-28 21:41:21','2025-08-28 21:41:26');
CREATE TABLE achievements (
	  id INTEGER PRIMARY KEY AUTOINCREMENT,
	  name TEXT NOT NULL,
	  description TEXT NOT NULL,
	  icon TEXT NOT NULL,
	  category_id INTEGER NOT NULL,
	  rarity TEXT NOT NULL DEFAULT 'common',
	  points INTEGER NOT NULL DEFAULT 0,
	  requirement INTEGER NOT NULL DEFAULT 1,
	  requirements_text TEXT NOT NULL,
	  is_hidden BOOLEAN DEFAULT 0,
	  created_at DATETIME DEFAULT CURRENT_TIMESTAMP, activity_type VARCHAR(100), requirements TEXT,
	  FOREIGN KEY (category_id) REFERENCES achievement_categories (id)
	);
INSERT INTO achievements VALUES(10,'Pierwszy post','Napisz swój pierwszy post na forum','mdi:comment-text',1,'common',10,1,'Napisz jeden post',0,'2025-08-28 23:36:34','post_created','{"min_posts": 1}');
INSERT INTO achievements VALUES(11,'Aktywny pisarz','Napisz 10 postów','mdi:comment-text-multiple',1,'uncommon',25,10,'Napisz 10 postów',0,'2025-08-28 23:36:34','post_created','{"min_posts": 10}');
INSERT INTO achievements VALUES(12,'Ekspert forów','Napisz 100 postów','mdi:comment-text-outline',1,'rare',50,100,'Napisz 100 postów',0,'2025-08-28 23:36:34','post_created','{"min_posts": 100}');
INSERT INTO achievements VALUES(13,'Twórca wątków','Utwórz 5 wątków','mdi:forum',2,'uncommon',30,5,'Utwórz 5 wątków',0,'2025-08-28 23:36:34','thread_created','{"min_threads": 5}');
INSERT INTO achievements VALUES(14,'Edytor','Edytuj 10 postów','mdi:pencil',3,'common',15,10,'Edytuj 10 postów',0,'2025-08-28 23:36:34','post_edited','{"min_edits": 10}');
CREATE TABLE achievement_categories (
	  id INTEGER PRIMARY KEY AUTOINCREMENT,
	  name TEXT NOT NULL,
	  icon TEXT NOT NULL,
	  description TEXT,
	  position INTEGER DEFAULT 0
	);
INSERT INTO achievement_categories VALUES(1,'Aktywność','mdi:forum','Osiągnięcia związane z aktywnością na forum',1);
INSERT INTO achievement_categories VALUES(2,'Tworzenie treści','mdi:creation','Osiągnięcia za tworzenie treści',2);
INSERT INTO achievement_categories VALUES(3,'Społeczność','mdi:account-group','Osiągnięcia społecznościowe',3);
INSERT INTO achievement_categories VALUES(4,'Ekspert','mdi:star','Osiągnięcia eksperckie',4);
CREATE TABLE user_achievements (
	  id INTEGER PRIMARY KEY AUTOINCREMENT,
	  user_id INTEGER NOT NULL,
	  achievement_id INTEGER NOT NULL,
	  progress INTEGER DEFAULT 0,
	  unlocked BOOLEAN DEFAULT 0,
	  unlocked_at DATETIME,
	  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	  FOREIGN KEY (user_id) REFERENCES users (id),
	  FOREIGN KEY (achievement_id) REFERENCES achievements (id),
	  UNIQUE(user_id, achievement_id)
	);
INSERT INTO user_achievements VALUES(1,1,13,5,1,'2025-08-29T00:06:16.058Z','2025-08-29 00:06:16','2025-08-29 00:06:16');
INSERT INTO user_achievements VALUES(2,1,10,1,1,'2025-08-29T00:07:59.648Z','2025-08-29 00:07:59','2025-08-29 00:07:59');
CREATE TABLE achievement_progress (
	  id INTEGER PRIMARY KEY AUTOINCREMENT,
	  user_id INTEGER NOT NULL,
	  achievement_id INTEGER NOT NULL,
	  progress_data TEXT,
	  last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
	  FOREIGN KEY (user_id) REFERENCES users (id),
	  FOREIGN KEY (achievement_id) REFERENCES achievements (id),
	  UNIQUE(user_id, achievement_id)
	);
CREATE TABLE user_activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    activity_type VARCHAR(100) NOT NULL,
    target_id INTEGER,
    target_type VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
INSERT INTO user_activities VALUES(1,1,'thread_created',NULL,NULL,'2025-08-28 23:40:08');
INSERT INTO user_activities VALUES(2,1,'thread_created',10,'thread','2025-08-28 23:40:08');
INSERT INTO user_activities VALUES(3,1,'post_created',19,'post','2025-08-28 23:40:08');
INSERT INTO user_activities VALUES(4,1,'thread_created',NULL,NULL,'2025-08-28 23:49:50');
INSERT INTO user_activities VALUES(5,1,'thread_created',11,'thread','2025-08-28 23:49:50');
INSERT INTO user_activities VALUES(6,1,'post_created',20,'post','2025-08-28 23:49:50');
INSERT INTO user_activities VALUES(7,1,'thread_created',11,'thread','2025-08-28 23:49:50');
INSERT INTO user_activities VALUES(8,1,'thread_created',12,'thread','2025-08-28 23:51:35');
INSERT INTO user_activities VALUES(9,1,'thread_created',NULL,NULL,'2025-08-28 23:51:35');
INSERT INTO user_activities VALUES(10,1,'post_created',21,'post','2025-08-28 23:51:35');
INSERT INTO user_activities VALUES(11,1,'thread_created',12,'thread','2025-08-28 23:51:35');
INSERT INTO user_activities VALUES(12,1,'thread_created',NULL,NULL,'2025-08-28 23:58:42');
INSERT INTO user_activities VALUES(13,1,'thread_created',13,'thread','2025-08-28 23:58:42');
INSERT INTO user_activities VALUES(14,1,'post_created',22,'post','2025-08-28 23:58:42');
INSERT INTO user_activities VALUES(15,1,'thread_created',13,'thread','2025-08-28 23:58:42');
INSERT INTO user_activities VALUES(16,1,'thread_created',NULL,NULL,'2025-08-29 00:02:08');
INSERT INTO user_activities VALUES(17,1,'thread_created',14,'thread','2025-08-29 00:02:08');
INSERT INTO user_activities VALUES(18,1,'post_created',23,'post','2025-08-29 00:02:08');
INSERT INTO user_activities VALUES(19,1,'thread_created',14,'thread','2025-08-29 00:02:08');
INSERT INTO user_activities VALUES(20,1,'thread_created',NULL,NULL,'2025-08-29 00:06:16');
INSERT INTO user_activities VALUES(21,1,'thread_created',15,'thread','2025-08-29 00:06:16');
INSERT INTO user_activities VALUES(22,1,'post_created',24,'post','2025-08-29 00:06:16');
INSERT INTO user_activities VALUES(23,1,'thread_created',15,'thread','2025-08-29 00:06:16');
INSERT INTO user_activities VALUES(24,1,'post_created',25,'post','2025-08-29 00:07:59');
INSERT INTO user_activities VALUES(25,1,'post_created',25,'post','2025-08-29 00:07:59');
CREATE TABLE backup_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'full',
      frequency TEXT NOT NULL DEFAULT 'daily',
      time TEXT NOT NULL DEFAULT '02:00',
      retention INTEGER NOT NULL DEFAULT 7,
      enabled BOOLEAN NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('roles',6);
INSERT INTO sqlite_sequence VALUES('categories',6);
INSERT INTO sqlite_sequence VALUES('users',2);
INSERT INTO sqlite_sequence VALUES('threads',15);
INSERT INTO sqlite_sequence VALUES('posts',25);
INSERT INTO sqlite_sequence VALUES('thread_subscriptions',2);
INSERT INTO sqlite_sequence VALUES('user_notification_settings',7);
INSERT INTO sqlite_sequence VALUES('user_pm_settings',4);
INSERT INTO sqlite_sequence VALUES('private_messages',5);
INSERT INTO sqlite_sequence VALUES('notifications',4);
INSERT INTO sqlite_sequence VALUES('reputation_votes',2);
INSERT INTO sqlite_sequence VALUES('achievement_categories',4);
INSERT INTO sqlite_sequence VALUES('achievements',14);
INSERT INTO sqlite_sequence VALUES('user_activities',25);
INSERT INTO sqlite_sequence VALUES('user_achievements',2);
CREATE INDEX idx_pm_conversation ON private_messages (conversation_id);
CREATE INDEX idx_pm_sender ON private_messages (sender_id);
CREATE INDEX idx_pm_receiver ON private_messages (receiver_id);
CREATE INDEX idx_pm_read ON private_messages (is_read);
CREATE INDEX idx_reputation_votes_target ON reputation_votes (target_type, target_id);
CREATE INDEX idx_reputation_votes_user ON reputation_votes (user_id);
CREATE INDEX idx_reputation_votes_created ON reputation_votes (created_at);
CREATE INDEX idx_user_achievements_user ON user_achievements (user_id);
CREATE INDEX idx_user_achievements_achievement ON user_achievements (achievement_id);
CREATE INDEX idx_achievement_progress_user ON achievement_progress (user_id);
CREATE INDEX idx_user_activities_user_id ON user_activities(user_id);
CREATE INDEX idx_user_activities_type ON user_activities(activity_type);
CREATE INDEX idx_user_activities_created ON user_activities(created_at);
CREATE TRIGGER after_post_insert
AFTER INSERT ON posts
FOR EACH ROW
BEGIN
    INSERT INTO user_activities (user_id, activity_type, target_id, target_type)
    VALUES (NEW.user_id, 'post_created', NEW.id, 'post');
END;
CREATE TRIGGER after_thread_insert
AFTER INSERT ON threads
FOR EACH ROW
BEGIN
    INSERT INTO user_activities (user_id, activity_type, target_id, target_type)
    VALUES (NEW.user_id, 'thread_created', NEW.id, 'thread');
END;
COMMIT;
