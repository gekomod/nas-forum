PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      icon TEXT DEFAULT 'mdi:account',
      priority INTEGER DEFAULT 500,
      color TEXT DEFAULT '#409EFF',
      is_default BOOLEAN DEFAULT 0,
      is_system BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
INSERT INTO roles VALUES(1,'Administrator','Pełne uprawnienia administracyjne','mdi:shield-account',1,'#F56C6C',1,1,'2025-08-31 11:18:27');
INSERT INTO roles VALUES(2,'Moderator','Uprawnienia moderatorskie','mdi:moderator',10,'#E6A23C',0,1,'2025-08-31 11:18:27');
INSERT INTO roles VALUES(3,'Użytkownik','Podstawowy użytkownik','mdi:account',500,'#909399',1,1,'2025-08-31 11:18:27');
INSERT INTO roles VALUES(4,'Zbanowany','Zablokowany użytkownik','mdi:block-helper',1000,'#000000',0,1,'2025-08-31 11:18:27');
INSERT INTO roles VALUES(5,'VIP','Użytkownik z dodatkowymi przywilejami','mdi:crown',100,'#67C23A',0,0,'2025-08-31 11:18:27');
INSERT INTO roles VALUES(6,'Redaktor','Tworzenie i edycja treści','mdi:pencil',50,'#409EFF',0,0,'2025-08-31 11:18:27');
CREATE TABLE backup_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'full',
      frequency TEXT NOT NULL DEFAULT 'daily',
      time TEXT NOT NULL DEFAULT '02:00',
      retention INTEGER NOT NULL DEFAULT 7,
      enabled BOOLEAN NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
CREATE TABLE permissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      category TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
INSERT INTO permissions VALUES(1,'manage_users','Zarządzanie użytkownikami','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(2,'manage_categories','Zarządzanie kategoriami','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(3,'manage_threads','Zarządzanie wątkami','Moderacja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(4,'manage_posts','Zarządzanie postami','Moderacja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(5,'delete_any_content','Usuwanie dowolnych treści','Moderacja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(6,'assign_roles','Przypisywanie ról','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(7,'manage_backups','Zarządzanie backupami','System','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(8,'view_roles','Przeglądanie ról','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(9,'create_role','Tworzenie ról','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(10,'edit_role','Edycja ról','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(11,'delete_role','Usuwanie ról','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(12,'view_role_users','Przeglądanie użytkowników roli','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(13,'add_user_to_role','Dodawanie użytkownika do roli','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(14,'remove_user_from_role','Usuwanie użytkownika z roli','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(15,'view_permissions','Przeglądanie uprawnień','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(16,'edit_permission_roles','Edycja ról uprawnienia','Administracja','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(17,'view_category_permissions','Przeglądanie uprawnień kategorii','Kategorie','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(18,'edit_category_permissions','Edycja uprawnień kategorii','Kategorie','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(19,'view_audit_logs','Przeglądanie logów audytu','System','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(20,'view_stats','Przeglądanie statystyk','System','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(21,'search_users','Wyszukiwanie użytkowników','Użytkownicy','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(22,'create_posts','Tworzenie postów','Forum','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(23,'create_threads','Tworzenie wątków','Forum','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(24,'edit_own_content','Edycja własnych treści','Forum','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(25,'delete_own_content','Usuwanie własnych treści','Forum','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(26,'extended_signature','Rozszerzony podpis','Użytkownicy','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(27,'custom_avatar','Niestandardowy avatar','Użytkownicy','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(28,'create_announcements','Tworzenie ogłoszeń','Forum','2025-08-31 11:18:27');
INSERT INTO permissions VALUES(29,'delete_permission','Usuwanie Uprawnien','Administracja',NULL);
INSERT INTO permissions VALUES(30,'edit_permission','Edycja Uprawnień','Administracja',NULL);
INSERT INTO permissions VALUES(31,'create_permission','Tworzenie Uprawnień','Administracja',NULL);
CREATE TABLE permission_roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      permission_id INTEGER NOT NULL,
      role_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE,
      FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
      UNIQUE(permission_id, role_id)
    );
INSERT INTO permission_roles VALUES(2,6,1,'2025-08-31 11:18:27');
INSERT INTO permission_roles VALUES(3,28,1,'2025-08-31 11:18:27');
INSERT INTO permission_roles VALUES(4,22,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(5,9,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(6,23,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(7,27,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(8,5,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(9,25,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(10,11,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(11,18,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(12,24,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(13,16,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(14,10,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(15,26,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(16,7,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(17,2,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(18,4,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(19,3,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(20,1,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(21,14,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(22,21,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(23,19,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(24,17,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(25,15,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(26,12,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(27,8,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(28,20,1,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(29,3,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(30,4,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(31,5,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(32,22,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(33,23,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(34,24,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(35,25,2,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(36,22,3,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(37,23,3,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(38,24,3,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(39,25,3,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(40,22,5,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(41,23,5,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(42,24,5,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(43,25,5,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(44,26,5,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(45,27,5,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(46,22,6,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(47,23,6,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(48,24,6,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(49,25,6,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(50,28,6,'2025-08-31 11:18:28');
INSERT INTO permission_roles VALUES(51,13,1,'2025-08-31 18:47:23');
INSERT INTO permission_roles VALUES(52,29,1,'2025-09-01 03:26:24');
INSERT INTO permission_roles VALUES(53,30,1,'2025-09-01 03:27:07');
INSERT INTO permission_roles VALUES(54,31,1,'2025-09-01 03:28:10');
CREATE TABLE user_roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      role_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
      FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
      UNIQUE(user_id, role_id)
    );
INSERT INTO user_roles VALUES(1,1,1,'2025-08-31 11:24:28');
INSERT INTO user_roles VALUES(2,2,3,'2025-08-31 16:13:12');
CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      avatar TEXT,
      signature TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME,
      is_banned BOOLEAN DEFAULT 0,
      location TEXT DEFAULT NULL,
      website TEXT DEFAULT NULL,
      bio TEXT DEFAULT NULL,
      reputation INTEGER DEFAULT 0,
      notification_settings TEXT DEFAULT '{"email_notifications": true, "push_notifications": true}'
    );
INSERT INTO users VALUES(1,'admin','jnowakk11@gmail.com','$2b$10$QN5MXjn/zZOaOhQCVPRhBOOY3ISveyrBw5Y8mSL/CybIxGOuAJl.i','/uploads/avatars/avatar-undefined-1756643004860-390818174.jpeg',NULL,'2025-08-31 11:24:28','2025-09-01 14:36:18',0,NULL,NULL,NULL,45,'{"email_notifications": true, "push_notifications": true}');
INSERT INTO users VALUES(2,'test','zaba141@o2.pl','$2b$10$iu5jzrSE1NaeLAkImAZVnevP87q48w8K40aRrRDN2wBchByqK42PG',NULL,NULL,'2025-08-31 16:13:12','2025-08-31 18:13:51',0,NULL,NULL,NULL,1,'{"email_notifications": true, "push_notifications": true}');
CREATE TABLE categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      icon TEXT,
      description TEXT,
      threads INTEGER DEFAULT 0,
      posts INTEGER DEFAULT 0,
      last_post_author TEXT,
      last_post_time TEXT,
      is_locked BOOLEAN DEFAULT 0,
      position INTEGER DEFAULT 0,
      required_role INTEGER DEFAULT NULL
    );
INSERT INTO categories VALUES(1,'Ogłoszenia','mdi:bullhorn','Ogłoszenia administracji i ważne informacje',50,209,'admin','2025-08-29T00:06:16.009Z',0,NULL,1);
INSERT INTO categories VALUES(2,'Problemy techniczne','mdi:tools','Problemy z konfiguracją, instalacją i działaniem NAS',328,1545,'admin','2025-08-22T22:55:00.689Z',0,5,NULL);
INSERT INTO categories VALUES(3,'Dyskusje ogólne','mdi:forum','Ogólne dyskusje dotyczące NAS i nie tylko',572,2889,'admin','2025-08-29T00:07:59.572Z',0,2,NULL);
INSERT INTO categories VALUES(4,'Propozycje','mdi:lightbulb','Propozycje nowych funkcji i usprawnień',192,874,'Tomasz Wiśniewski','1 godzinę temu',0,4,NULL);
INSERT INTO categories VALUES(5,'Off-top','mdi:chat','Dyskusje na dowolne tematy niezwiązane z NAS',112,377,'admin','2025-08-31T16:14:27.834Z',0,1,NULL);
INSERT INTO categories VALUES(6,'Pobieralnia','mdi:folder','Pliki do pobrania, Aktualne wersje, Dodatki, Pluginy.',0,0,NULL,NULL,1,3,NULL);
CREATE TABLE threads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category_id INTEGER,
      user_id INTEGER,
      title TEXT NOT NULL,
      tag TEXT,
      author TEXT NOT NULL,
      date TEXT,
      replies INTEGER DEFAULT 0,
      views INTEGER DEFAULT 0,
      is_closed INTEGER DEFAULT 0,
      is_sticky INTEGER DEFAULT 0,
      last_post_author TEXT,
      last_post_time TEXT,
      FOREIGN KEY (category_id) REFERENCES categories (id),
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO threads VALUES(1,5,2,'test fff','','test','2025-08-31T16:14:03.304Z',1,6,0,0,'admin','2025-08-31T16:14:27.834Z');
CREATE TABLE posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id INTEGER,
      user_id INTEGER,
      author TEXT NOT NULL,
      content TEXT,
      date TEXT,
      edited_at DATETIME,
      FOREIGN KEY (thread_id) REFERENCES threads (id),
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO posts VALUES(1,1,2,'test','dhsh sd fhfg hh','2025-08-31T16:14:03.304Z',NULL);
INSERT INTO posts VALUES(2,1,1,'admin','Odpowiedź :) jakaś fajna może nie ','2025-08-31T16:14:27.834Z',NULL);
CREATE TABLE thread_subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      thread_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (thread_id) REFERENCES threads (id),
      UNIQUE(user_id, thread_id)
    );
CREATE TABLE notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      related_thread_id INTEGER,
      related_post_id INTEGER,
      related_user_id INTEGER,
      is_read BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO notifications VALUES(1,1,'system','test','dfgdfgdfh',NULL,NULL,1,1,'2025-08-31 14:58:23');
INSERT INTO notifications VALUES(2,1,'achievement','Nowe osiągnięcie!','Odblokowałeś osiągnięcie: <strong>Pierwszy post</strong> - Napisz swój pierwszy post',NULL,NULL,NULL,1,'2025-08-31 16:14:27');
INSERT INTO notifications VALUES(3,1,'achievement','Nowe osiągnięcie!','Odblokowałeś osiągnięcie: <strong>Pierwsze kroki</strong> - Zaloguj się po raz pierwszy',NULL,NULL,NULL,1,'2025-08-31 18:31:30');
INSERT INTO notifications VALUES(4,1,'achievement','Nowe osiągnięcie!','Odblokowałeś osiągnięcie: <strong>Regularny bywalec</strong> - Zaloguj się 10 razy',NULL,NULL,NULL,1,'2025-08-31 18:31:30');
CREATE TABLE user_notification_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      email_notifications BOOLEAN DEFAULT 1,
      push_notifications BOOLEAN DEFAULT 1,
      notify_on_reply BOOLEAN DEFAULT 1,
      notify_on_mention BOOLEAN DEFAULT 1,
      notify_on_thread_update BOOLEAN DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users (id),
      UNIQUE(user_id)
    );
INSERT INTO user_notification_settings VALUES(2,1,1,1,1,1,1);
INSERT INTO user_notification_settings VALUES(3,2,1,1,1,1,1);
CREATE TABLE user_read_threads (
      user_id INTEGER,
      thread_id INTEGER,
      read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, thread_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (thread_id) REFERENCES threads(id)
    );
INSERT INTO user_read_threads VALUES(2,1,'2025-08-31 16:14:05');
INSERT INTO user_read_threads VALUES(1,1,'2025-09-01 09:18:53');
CREATE TABLE user_read_posts (
      user_id INTEGER,
      post_id INTEGER,
      read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, post_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (post_id) REFERENCES posts(id)
    );
INSERT INTO user_read_posts VALUES(2,1,'2025-08-31 16:14:05');
INSERT INTO user_read_posts VALUES(1,1,'2025-09-01 09:18:53');
INSERT INTO user_read_posts VALUES(1,2,'2025-09-01 09:18:53');
CREATE TABLE user_category_visits (
      user_id INTEGER,
      category_id INTEGER,
      last_visit DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, category_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (category_id) REFERENCES categories(id)
    );
INSERT INTO user_category_visits VALUES(1,3,'2025-08-31 15:28:49');
INSERT INTO user_category_visits VALUES(1,2,'2025-08-31 16:09:52');
INSERT INTO user_category_visits VALUES(1,6,'2025-08-31 16:11:49');
INSERT INTO user_category_visits VALUES(2,4,'2025-08-31 16:13:37');
INSERT INTO user_category_visits VALUES(2,6,'2025-08-31 16:13:40');
INSERT INTO user_category_visits VALUES(2,3,'2025-08-31 16:13:43');
INSERT INTO user_category_visits VALUES(2,1,'2025-08-31 16:13:51');
INSERT INTO user_category_visits VALUES(2,5,'2025-08-31 16:14:05');
INSERT INTO user_category_visits VALUES(1,5,'2025-09-01 09:18:53');
CREATE TABLE private_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id TEXT NOT NULL,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      is_read BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sender_id) REFERENCES users (id),
      FOREIGN KEY (receiver_id) REFERENCES users (id)
    );
CREATE TABLE audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id INTEGER,
      details TEXT,
      ip_address TEXT,
      user_agent TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
    );
CREATE TABLE user_pm_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      allow_private_messages BOOLEAN DEFAULT 1,
      notify_on_pm BOOLEAN DEFAULT 1,
      save_sent_messages BOOLEAN DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
INSERT INTO user_pm_settings VALUES(2,1,1,1,1);
INSERT INTO user_pm_settings VALUES(3,2,1,1,1);
CREATE TABLE reputation_votes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      target_type TEXT NOT NULL CHECK (target_type IN ('post', 'thread')),
      target_id INTEGER NOT NULL,
      vote_type TEXT NOT NULL CHECK (vote_type IN ('upvote', 'downvote')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      UNIQUE(user_id, target_type, target_id)
    );
INSERT INTO reputation_votes VALUES(1,1,'post',1,'upvote','2025-08-31 18:27:41','2025-08-31 18:27:41');
CREATE TABLE achievement_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      icon TEXT NOT NULL,
      description TEXT,
      position INTEGER DEFAULT 0
    );
INSERT INTO achievement_categories VALUES(1,'Aktywność na forum','mdi:forum','Osiągnięcia związane z aktywnością na forum',1);
INSERT INTO achievement_categories VALUES(2,'Tworzenie treści','mdi:creation','Osiągnięcia za tworzenie wątków i postów',2);
INSERT INTO achievement_categories VALUES(3,'Popularność','mdi:star','Osiągnięcia za popularność i reputację',3);
INSERT INTO achievement_categories VALUES(4,'Edycja','mdi:pencil','Osiągnięcia za edycję treści',4);
INSERT INTO achievement_categories VALUES(5,'Zaangażowanie','mdi:calendar','Osiągnięcia za regularną aktywność',5);
CREATE TABLE user_achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      achievement_id INTEGER NOT NULL,
      progress INTEGER DEFAULT 0,
      unlocked BOOLEAN DEFAULT 0,
      unlocked_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (achievement_id) REFERENCES achievements (id),
      UNIQUE(user_id, achievement_id)
    );
INSERT INTO user_achievements VALUES(1,1,3,1,1,'2025-08-31T16:14:27.892Z','2025-08-31 16:14:27','2025-08-31 16:14:27');
INSERT INTO user_achievements VALUES(2,1,1,1,1,'2025-08-31T18:31:30.242Z','2025-08-31 18:31:30','2025-08-31 18:31:30');
INSERT INTO user_achievements VALUES(3,1,2,10,1,'2025-08-31T18:31:30.313Z','2025-08-31 18:31:30','2025-08-31 18:31:30');
CREATE TABLE achievement_progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      achievement_id INTEGER NOT NULL,
      progress_data TEXT,
      last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (achievement_id) REFERENCES achievements (id),
      UNIQUE(user_id, achievement_id)
    );
CREATE TABLE user_activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      activity_type VARCHAR(100) NOT NULL,
      target_id INTEGER,
      target_type VARCHAR(50),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
INSERT INTO user_activities VALUES(1,2,'thread_created',NULL,NULL,'2025-08-31 16:14:03');
INSERT INTO user_activities VALUES(2,2,'thread_created',1,'thread','2025-08-31 16:14:03');
INSERT INTO user_activities VALUES(3,2,'post_created',1,'post','2025-08-31 16:14:03');
INSERT INTO user_activities VALUES(4,2,'thread_created',1,'thread','2025-08-31 16:14:03');
INSERT INTO user_activities VALUES(5,1,'post_created',2,'post','2025-08-31 16:14:27');
INSERT INTO user_activities VALUES(6,1,'post_created',2,'post','2025-08-31 16:14:27');
INSERT INTO user_activities VALUES(7,1,'post_created',1,'post','2025-08-31 16:14:28');
INSERT INTO user_activities VALUES(8,1,'user_login',1,'user','2025-08-31 18:31:30');
CREATE TABLE auth_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      token TEXT UNIQUE NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
CREATE TABLE IF NOT EXISTS "achievements" (
	"id"	INTEGER,
	"name"	VARCHAR(100) NOT NULL,
	"description"	TEXT,
	"icon"	TEXT,
	"category_id"	INTEGER,
	"rarity"	VARCHAR(20) DEFAULT 'common',
	"points"	INTEGER DEFAULT 0,
	"requirement"	INTEGER DEFAULT 1,
	"requirements_text"	TEXT,
	"is_hidden"	BOOLEAN DEFAULT 0,
	"created_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	"requirements"	TEXT,
	"activity_type"	VARCHAR(100),
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("category_id") REFERENCES "achievement_categories"("id")
);
INSERT INTO achievements VALUES(1,'Pierwsze kroki','Zaloguj się po raz pierwszy','mdi:login',1,'common',10,1,'Zaloguj się na forum',0,'2025-08-29 00:22:39','{"min_logins": 1}','user_login');
INSERT INTO achievements VALUES(2,'Regularny bywalec','Zaloguj się 10 razy','mdi:calendar',1,'uncommon',20,10,'Zaloguj się 10 razy',0,'2025-08-29 00:22:39','{"min_logins": 10}','user_login');
INSERT INTO achievements VALUES(3,'Pierwszy post','Napisz swój pierwszy post','mdi:comment-text',2,'common',15,1,'Napisz jeden post',0,'2025-08-29 00:22:39','{"min_posts": 1}','post_created');
INSERT INTO achievements VALUES(4,'Aktywny użytkownik','Napisz 10 postów','mdi:comment-text-multiple',2,'uncommon',30,10,'Napisz 10 postów',0,'2025-08-29 00:22:39','{"min_posts": 10}','post_created');
INSERT INTO achievements VALUES(5,'Ekspert forów','Napisz 100 postów','mdi:comment-text-outline',2,'rare',50,100,'Napisz 100 postów',0,'2025-08-29 00:22:39','{"min_posts": 100}','post_created');
INSERT INTO achievements VALUES(6,'Twórca wątków','Utwórz 5 wątków','mdi:forum',2,'uncommon',25,5,'Utwórz 5 wątków',0,'2025-08-29 00:22:39','{"min_threads": 5}','thread_created');
INSERT INTO achievements VALUES(7,'Mistrz dyskusji','Utwórz 20 wątków','mdi:forum-outline',2,'rare',40,20,'Utwórz 20 wątków',0,'2025-08-29 00:22:39','{"min_threads": 20}','thread_created');
INSERT INTO achievements VALUES(8,'Pierwszy like','Otrzymaj pierwszy like','mdi:thumb-up',3,'common',10,1,'Otrzymaj jeden like',0,'2025-08-29 00:22:39','{"min_likes": 1}','post_liked');
INSERT INTO achievements VALUES(9,'Popularny użytkownik','Otrzymaj 10 likeów','mdi:thumb-up',3,'uncommon',25,10,'Otrzymaj 10 likeów',0,'2025-08-29 00:22:39','{"min_likes": 10}','post_liked');
INSERT INTO achievements VALUES(10,'Gwiazda forów','Otrzymaj 100 likeów','mdi:star',3,'rare',50,100,'Otrzymaj 100 likeów',0,'2025-08-29 00:22:39','{"min_likes": 100}','post_liked');
INSERT INTO achievements VALUES(11,'Pozytywna reputacja','Zdobyj 50 punktów reputacji','mdi:trending-up',3,'uncommon',30,50,'Zdobyj 50 punktów reputacji',0,'2025-08-29 00:22:39','{"min_reputation": 50}','reputation_gained');
INSERT INTO achievements VALUES(12,'Doskonałość','Edytuj swój pierwszy post','mdi:pencil',4,'common',5,1,'Edytuj jeden post',0,'2025-08-29 00:22:39','{"min_edits": 1}','post_edited');
INSERT INTO achievements VALUES(13,'Perfekcjonista','Edytuj 10 postów','mdi:pencil-box',4,'uncommon',15,10,'Edytuj 10 postów',0,'2025-08-29 00:22:39','{"min_edits": 10}','post_edited');
INSERT INTO achievements VALUES(14,'Tygodniowa aktywność','Bądź aktywny przez 7 dni z rzędu','mdi:calendar-week',5,'uncommon',20,7,'Bądź aktywny przez 7 dni',0,'2025-08-29 00:22:39','{"consecutive_days": 7}','daily_activity');
INSERT INTO achievements VALUES(15,'Miesięczny maraton','Bądź aktywny przez 30 dni','mdi:calendar-month',5,'rare',40,30,'Bądź aktywny przez 30 dni',0,'2025-08-29 00:22:39','{"consecutive_days": 30}','daily_activity');
INSERT INTO achievements VALUES(16,'Roczny weteran','Bądź aktywny przez 365 dni','mdi:calendar-year',5,'legendary',100,365,'Bądź aktywny przez rok',0,'2025-08-29 00:22:39','{"consecutive_days": 365}','daily_activity');
CREATE TABLE IF NOT EXISTS "category_permissions" (
	"id"	INTEGER,
	"category_id"	INTEGER NOT NULL,
	"permission_id"	INTEGER NOT NULL,
	"created_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	"permission_type"	TEXT DEFAULT 'read',
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("category_id") REFERENCES "categories"("id") ON DELETE CASCADE,
	FOREIGN KEY("permission_id") REFERENCES "permissions"("id") ON DELETE CASCADE
);
INSERT INTO category_permissions VALUES(152,3,1,'2025-09-01 04:06:39','read');
INSERT INTO category_permissions VALUES(153,3,2,'2025-09-01 04:06:39','read');
INSERT INTO category_permissions VALUES(154,3,6,'2025-09-01 04:06:39','read');
INSERT INTO category_permissions VALUES(155,3,3,'2025-09-01 04:06:39','read');
INSERT INTO category_permissions VALUES(156,3,5,'2025-09-01 04:06:39','read');
INSERT INTO category_permissions VALUES(170,3,1,'2025-09-01 04:09:03','write');
INSERT INTO category_permissions VALUES(171,3,2,'2025-09-01 04:09:03','write');
INSERT INTO category_permissions VALUES(172,3,6,'2025-09-01 04:09:03','write');
INSERT INTO category_permissions VALUES(173,3,3,'2025-09-01 04:09:03','write');
INSERT INTO category_permissions VALUES(174,3,5,'2025-09-01 04:09:03','write');
INSERT INTO category_permissions VALUES(176,3,1,'2025-09-01 04:09:13','moderate');
INSERT INTO category_permissions VALUES(177,3,2,'2025-09-01 04:09:13','moderate');
INSERT INTO category_permissions VALUES(188,5,1,'2025-09-01 04:09:25','read');
INSERT INTO category_permissions VALUES(189,5,2,'2025-09-01 04:09:25','read');
INSERT INTO category_permissions VALUES(190,5,6,'2025-09-01 04:09:25','read');
INSERT INTO category_permissions VALUES(191,5,3,'2025-09-01 04:09:25','read');
INSERT INTO category_permissions VALUES(192,5,5,'2025-09-01 04:09:25','read');
INSERT INTO category_permissions VALUES(203,5,1,'2025-09-01 04:09:32','write');
INSERT INTO category_permissions VALUES(204,5,2,'2025-09-01 04:09:32','write');
INSERT INTO category_permissions VALUES(205,5,6,'2025-09-01 04:09:32','write');
INSERT INTO category_permissions VALUES(206,5,3,'2025-09-01 04:09:32','write');
INSERT INTO category_permissions VALUES(207,5,5,'2025-09-01 04:09:32','write');
INSERT INTO category_permissions VALUES(209,5,1,'2025-09-01 04:09:34','moderate');
INSERT INTO category_permissions VALUES(210,5,2,'2025-09-01 04:09:34','moderate');
INSERT INTO category_permissions VALUES(221,1,1,'2025-09-01 04:09:40','read');
INSERT INTO category_permissions VALUES(222,1,2,'2025-09-01 04:09:40','read');
INSERT INTO category_permissions VALUES(223,1,6,'2025-09-01 04:09:40','read');
INSERT INTO category_permissions VALUES(224,1,3,'2025-09-01 04:09:40','read');
INSERT INTO category_permissions VALUES(225,1,5,'2025-09-01 04:09:40','read');
INSERT INTO category_permissions VALUES(227,1,1,'2025-09-01 04:09:43','write');
INSERT INTO category_permissions VALUES(228,1,2,'2025-09-01 04:09:43','write');
INSERT INTO category_permissions VALUES(230,1,1,'2025-09-01 04:09:48','moderate');
INSERT INTO category_permissions VALUES(231,1,2,'2025-09-01 04:09:48','moderate');
INSERT INTO category_permissions VALUES(242,6,1,'2025-09-01 04:09:55','read');
INSERT INTO category_permissions VALUES(243,6,2,'2025-09-01 04:09:55','read');
INSERT INTO category_permissions VALUES(244,6,6,'2025-09-01 04:09:55','read');
INSERT INTO category_permissions VALUES(245,6,3,'2025-09-01 04:09:55','read');
INSERT INTO category_permissions VALUES(246,6,5,'2025-09-01 04:09:55','read');
INSERT INTO category_permissions VALUES(248,6,1,'2025-09-01 04:09:57','write');
INSERT INTO category_permissions VALUES(249,6,2,'2025-09-01 04:09:57','write');
INSERT INTO category_permissions VALUES(251,6,1,'2025-09-01 04:10:00','moderate');
INSERT INTO category_permissions VALUES(252,6,2,'2025-09-01 04:10:00','moderate');
INSERT INTO category_permissions VALUES(263,2,1,'2025-09-01 04:10:09','read');
INSERT INTO category_permissions VALUES(264,2,2,'2025-09-01 04:10:09','read');
INSERT INTO category_permissions VALUES(265,2,6,'2025-09-01 04:10:09','read');
INSERT INTO category_permissions VALUES(266,2,3,'2025-09-01 04:10:09','read');
INSERT INTO category_permissions VALUES(267,2,5,'2025-09-01 04:10:09','read');
INSERT INTO category_permissions VALUES(278,2,1,'2025-09-01 04:10:14','write');
INSERT INTO category_permissions VALUES(279,2,2,'2025-09-01 04:10:14','write');
INSERT INTO category_permissions VALUES(280,2,6,'2025-09-01 04:10:14','write');
INSERT INTO category_permissions VALUES(281,2,3,'2025-09-01 04:10:14','write');
INSERT INTO category_permissions VALUES(282,2,5,'2025-09-01 04:10:14','write');
INSERT INTO category_permissions VALUES(286,2,1,'2025-09-01 04:10:19','moderate');
INSERT INTO category_permissions VALUES(287,2,2,'2025-09-01 04:10:19','moderate');
INSERT INTO category_permissions VALUES(288,2,6,'2025-09-01 04:10:19','moderate');
INSERT INTO category_permissions VALUES(299,4,1,'2025-09-01 04:10:25','read');
INSERT INTO category_permissions VALUES(300,4,2,'2025-09-01 04:10:25','read');
INSERT INTO category_permissions VALUES(301,4,6,'2025-09-01 04:10:25','read');
INSERT INTO category_permissions VALUES(302,4,3,'2025-09-01 04:10:25','read');
INSERT INTO category_permissions VALUES(303,4,5,'2025-09-01 04:10:25','read');
INSERT INTO category_permissions VALUES(314,4,2,'2025-09-01 04:10:29','write');
INSERT INTO category_permissions VALUES(315,4,1,'2025-09-01 04:10:29','write');
INSERT INTO category_permissions VALUES(316,4,6,'2025-09-01 04:10:29','write');
INSERT INTO category_permissions VALUES(317,4,3,'2025-09-01 04:10:29','write');
INSERT INTO category_permissions VALUES(318,4,5,'2025-09-01 04:10:29','write');
INSERT INTO category_permissions VALUES(322,4,1,'2025-09-01 04:10:32','moderate');
INSERT INTO category_permissions VALUES(323,4,2,'2025-09-01 04:10:32','moderate');
INSERT INTO category_permissions VALUES(324,4,6,'2025-09-01 04:10:32','moderate');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('roles',6);
INSERT INTO sqlite_sequence VALUES('permissions',31);
INSERT INTO sqlite_sequence VALUES('permission_roles',54);
INSERT INTO sqlite_sequence VALUES('users',2);
INSERT INTO sqlite_sequence VALUES('user_roles',2);
INSERT INTO sqlite_sequence VALUES('user_notification_settings',3);
INSERT INTO sqlite_sequence VALUES('user_pm_settings',3);
INSERT INTO sqlite_sequence VALUES('notifications',4);
INSERT INTO sqlite_sequence VALUES('categories',6);
INSERT INTO sqlite_sequence VALUES('achievement_categories',5);
INSERT INTO sqlite_sequence VALUES('achievements',16);
INSERT INTO sqlite_sequence VALUES('user_activities',8);
INSERT INTO sqlite_sequence VALUES('threads',1);
INSERT INTO sqlite_sequence VALUES('posts',2);
INSERT INTO sqlite_sequence VALUES('user_achievements',3);
INSERT INTO sqlite_sequence VALUES('reputation_votes',1);
INSERT INTO sqlite_sequence VALUES('category_permissions',324);
CREATE INDEX idx_pm_conversation ON private_messages (conversation_id);
CREATE INDEX idx_pm_sender ON private_messages (sender_id);
CREATE INDEX idx_pm_receiver ON private_messages (receiver_id);
CREATE INDEX idx_pm_read ON private_messages (is_read);
CREATE INDEX idx_reputation_votes_target ON reputation_votes (target_type, target_id);
CREATE INDEX idx_user_achievements_user ON user_achievements (user_id);
CREATE INDEX idx_user_achievements_achievement ON user_achievements (achievement_id);
CREATE INDEX idx_achievement_progress_user ON achievement_progress (user_id);
CREATE INDEX idx_user_activities_user_id ON user_activities(user_id);
CREATE INDEX idx_user_activities_type ON user_activities(activity_type);
CREATE INDEX idx_user_activities_created ON user_activities(created_at);
CREATE TRIGGER after_post_insert
      AFTER INSERT ON posts
      FOR EACH ROW
      BEGIN
          INSERT INTO user_activities (user_id, activity_type, target_id, target_type)
          VALUES (NEW.user_id, 'post_created', NEW.id, 'post');
      END;
CREATE TRIGGER after_thread_insert
      AFTER INSERT ON threads
      FOR EACH ROW
      BEGIN
          INSERT INTO user_activities (user_id, activity_type, target_id, target_type)
          VALUES (NEW.user_id, 'thread_created', NEW.id, 'thread');
      END;
COMMIT;
